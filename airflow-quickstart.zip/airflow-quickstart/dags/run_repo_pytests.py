from __future__ import annotations
from datetime import datetime
import os
from airflow import DAG
from airflow.operators.bash import BashOperator

REPO_DIR = os.getenv("REPO_DIR", "/opt/airflow/Open_Source_ETL_Pipelines")

with DAG(
    dag_id="run_repo_pytests",
    start_date=datetime(2025, 9, 1),
    schedule_interval=None,
    catchup=False,
    tags=["tests", "pytest"],
) as dag:

    run_pytests = BashOperator(
        task_id="pytest",
        bash_command=f"cd {REPO_DIR} && pytest -q",
    )
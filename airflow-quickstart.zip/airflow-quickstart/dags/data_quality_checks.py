from __future__ import annotations
from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task
from airflow.providers.postgres.hooks.postgres import PostgresHook

DEFAULT_ARGS = {"owner": "dq", "retries": 0}

with DAG(
    dag_id="data_quality_checks",
    start_date=datetime(2025, 9, 1),
    schedule_interval=None,
    catchup=False,
    default_args=DEFAULT_ARGS,
    tags=["dq", "checks"],
) as dag:

    @task
    def row_count_check(table: str = "silver.customers_clean", min_rows: int = 1):
        pg = PostgresHook(postgres_conn_id="postgres_default")
        records = pg.get_first(f"SELECT COUNT(*) FROM {table};")
        assert records and records[0] >= min_rows, f"Row count check failed for {table}"

    @task
    def unique_customer_hash_check():
        pg = PostgresHook(postgres_conn_id="postgres_default")
        sql = """
        SELECT COUNT(*) AS total,
               COUNT(DISTINCT customer_hash) AS unique_hashes
        FROM gold.dim_customers;
        """
        total, unique_hashes = PostgresHook(postgres_conn_id="postgres_default").get_first(sql)
        assert total == unique_hashes, "Duplicate customer_hash values found in gold.dim_customers"

    row_count_check() >> unique_customer_hash_check()
from __future__ import annotations
from datetime import datetime
import os
from airflow import DAG
from airflow.operators.bash import BashOperator

DBT_DIR = os.getenv("DBT_DIR", "/opt/airflow/dbt")
PROFILE_DIR = os.getenv("DBT_PROFILES_DIR", f"{DBT_DIR}/profiles")
PROJECT_NAME = os.getenv("DBT_PROJECT", "elt_assignment")

ENV_PATH_PREFIX = 'export PATH="$PATH:/home/airflow/.local/bin"'

with DAG(
    dag_id="dbt_transformations",
    start_date=datetime(2025, 9, 1),
    schedule=None,
    catchup=False,
    tags=["dbt", "silver", "gold"],
) as dag:

    install_dbt = BashOperator(
        task_id="install_dbt",
        bash_command=(
            f'{ENV_PATH_PREFIX} && '
            'python -m pip install --user "dbt-postgres==1.8.7"'
        ),
    )

    dbt_deps = BashOperator(
        task_id="dbt_deps",
        bash_command=(
            f'{ENV_PATH_PREFIX} && '
            f"cd {DBT_DIR} && DBT_PROFILES_DIR={PROFILE_DIR} dbt deps"
        ),
    )

    dbt_run = BashOperator(
        task_id="dbt_run",
        bash_command=(
            f'{ENV_PATH_PREFIX} && '
            f"cd {DBT_DIR} && DBT_PROFILES_DIR={PROFILE_DIR} dbt run --project-dir . --profiles-dir {PROFILE_DIR}"
        ),
    )

    dbt_test = BashOperator(
        task_id="dbt_test",
        bash_command=(
            f'{ENV_PATH_PREFIX} && '
            f"cd {DBT_DIR} && DBT_PROFILES_DIR={PROFILE_DIR} dbt test --project-dir . --profiles-dir {PROFILE_DIR}"
        ),
    )

    install_dbt >> dbt_deps >> dbt_run >> dbt_test
-- Reference table created directly by Airflow/SQL COPY
-- dbt will just treat this as a source, not transform
select * from bronze.customers_raw